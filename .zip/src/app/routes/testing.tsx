import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";

const API_URL = "https://jsonplaceholder.typicode.com/posts";

export default function CrudExample() {
  const queryClient = useQueryClient();
  const [title, setTitle] = useState("");
  const [editingId, setEditingId] = useState(null);

  // 📖 READ
  const { data: posts, isLoading } = useQuery({
    queryKey: ["posts"],
    queryFn: async () => {
      const res = await axios.get(API_URL);
      return res.data.slice(0, 5); // limit data
    },
  });

  // ➕ CREATE
  const createMutation = useMutation({
    mutationFn: (newPost) => axios.post(API_URL, newPost),
    onSuccess: () => {
      queryClient.invalidateQueries(["posts"]);
      setTitle("");
    },
  });

  // ✏️ UPDATE
  const updateMutation = useMutation({
    mutationFn: ({ id, updatedPost }) =>
      axios.put(`${API_URL}/${id}`, updatedPost),
    onSuccess: () => {
      queryClient.invalidateQueries(["posts"]);
      setEditingId(null);
      setTitle("");
    },
  });

  // ❌ DELETE
  const deleteMutation = useMutation({
    mutationFn: (id) => axios.delete(`${API_URL}/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries(["posts"]);
    },
  });

  const handleSubmit = () => {
    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        updatedPost: { title },
      });
    } else {
      createMutation.mutate({ title });
    }
  };

  if (isLoading) return <p>Loading...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>CRUD with TanStack Query</h2>

      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Enter title"
      />
      <button onClick={handleSubmit}>{editingId ? "Update" : "Create"}</button>

      <ul>
        {posts?.map((post) => (
          <li key={post.id}>
            {post.title}
            <button
              onClick={() => {
                setEditingId(post.id);
                setTitle(post.title);
              }}
            >
              Edit
            </button>
            <button onClick={() => deleteMutation.mutate(post.id)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
